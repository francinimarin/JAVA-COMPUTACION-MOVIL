package com.example.mylogin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText user,pasword,confirm;
    Button  login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        user=(EditText) findViewById(R.id.EUser);
        pasword=(EditText) findViewById(R.id.EPasword);
        confirm=(EditText) findViewById(R.id.EPconfirm);
        login=(Button) findViewById(R.id.BtnLog);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (user.getText().toString().equals(""))
                {
                    Toast.makeText(MainActivity.this, "Es necesario tu usuario", Toast.LENGTH_SHORT).show();
                }else if (pasword.getText().toString().equals("")){
                    Toast.makeText(MainActivity.this, "Ingrasa alguna contraceña", Toast.LENGTH_SHORT).show();
                }else if (pasword.getText().toString().length()>6){
                    Toast.makeText(MainActivity.this, "tu contraceña no debe ser menor a 6 caracteres", Toast.LENGTH_SHORT).show();
                }else if (!confirm.getText().toString().equals(pasword.getText().toString())){
                    Toast.makeText(MainActivity.this, "Verifica tu contraceña ambas deben ser iguales", Toast.LENGTH_SHORT).show();
                }else {
                    Intent intent= new Intent(MainActivity.this,menu.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}
