package com.usc.crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudUscApplicationTests {

	@Test
	void contextLoads() {
	}

}
